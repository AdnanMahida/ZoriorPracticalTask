package com.ad.zoriorpracticaltask.ui.shared

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ad.zoriorpracticaltask.data.repository.BaseRepository
import kotlinx.coroutines.launch

abstract class BaseViewModel(
    private val baseRepository: BaseRepository
) : ViewModel() {
    //todo separate
}